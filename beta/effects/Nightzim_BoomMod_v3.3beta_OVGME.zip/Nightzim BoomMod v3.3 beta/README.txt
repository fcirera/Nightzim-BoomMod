Nightzim BoomMod v3.3 beta - OVGME package. Mods folder for the DCS game root. Do not combine with the .bat installer.
https://github.com/fcirera/Nightzim-BoomMod
