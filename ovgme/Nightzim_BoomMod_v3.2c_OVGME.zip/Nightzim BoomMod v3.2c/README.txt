Nightzim BoomMod v3.2c - OVGME / mod manager package
Put this folder (or the zip) in your OVGME mods folder for the DCS install (game root, not Saved Games) and enable it.
OVGME keeps its own backup of the original files. After a DCS update or repair: disable and re-enable the mod.
Do not use together with the .bat installer - pick one method.
https://github.com/fcirera/Nightzim-BoomMod
